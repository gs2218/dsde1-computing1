'''
question1.py

Implementation of the flowchart in question1.png.
'''

def flowchart(input_value):
    return

